# Jeremy Legal Records: Royalty Dashboard demo data pack (FICTIONAL)

> **Everything in this pack is made up.** "Jeremy Legal", the writers, the publisher, every song
> title, ISRC, ISWC, APRA work ID, IPI, PPL id, UPC and every dollar amount is invented.
> No real person's catalogue, registrations or earnings are in these files. The parody titles
> are jokes. Use them to try out the open-source Royalty Dashboard by Jeremy Legal Records.

License: **MIT** (see `LICENSE`). Copyright (c) 2026 Jeremy Legal Records.

## What it is

These files copy the *layout* of the exports an independent Australian artist actually gets:

1. **DistroKid** "all time" earnings export (CSV)
2. **SoundCloud** lifetime earnings report (CSV)
3. **APRA AMCOS** Works List plus quarterly APRA and AMCOS royalty statements (XLSX), plus the
   "Royalty Source Categories List" CSVs
4. **PPCA** repertoire (MyPPCA / PPL recordings, XLSX)

Column headers, column order, date and number formats, delimiters, currency codes, period
conventions and file names match the real exports, so an artist can drop in their own files later.

## Files

| File | Rows | What it mirrors |
|---|---:|---|
| `distrokid/distrokid_all_time_results.csv` | 12,514 | DistroKid all-time earnings export: 37 stores, 83 countries, 24 sale months (2024-09 to 2026-08), USD |
| `soundcloud/lifetime_earnings_report.csv` | 172 | SoundCloud for Artists lifetime earnings report: 167 `SOUNDCLOUD` rows (Nov 2025 to Apr 2026, USD) plus 5 other-partner rows the dashboard leaves out |
| `apra-amcos/Works List - 20260930.xlsx` | 21 | APRA AMCOS Works List export (sheet `DATA`) |
| `apra-amcos/statements/APRA Royalty Statement_000000_AUS_<MonYYYY>.xlsx` | 8 files, 17-24 lines each | APRA quarterly distributions Nov 2024 to Aug 2026, AUD |
| `apra-amcos/statements/APRA Royalty Statement_000000_NZ_<MonYYYY>.xlsx` | 2 files | APRA New Zealand (Feb 2026, Aug 2026), NZD |
| `apra-amcos/statements/AMCOS Royalty Statement_000000_AUS_<MonYYYY>.xlsx` | 7 files, 4-7 lines each | AMCOS mechanicals, AUD (includes MLC-remitted US lines) |
| `apra-amcos/statements/AMCOS Royalty Statement_000000_NZ_<MonYYYY>.xlsx` | 2 files | AMCOS New Zealand, NZD |
| `apra-amcos/statements/* Royalty Source Categories List_*.csv` | 4 files | APRA/AMCOS category roll-ups (AU and NZ variants) |
| `ppca/PPCA REPERTOIRE.xlsx` | 21 | PPCA / PPL recording repertoire (one artist sheet) |
| `csv/APRA_Works_List_20260930.csv` | 21 | Same Works List as a flat CSV |
| `csv/APRA_AMCOS_Royalty_Statements.csv` | 213 | All statement lines in one CSV (AUD and NZD kept separate, one `currency` column) |
| `csv/PPCA_REPERTOIRE.csv` | 21 | PPCA repertoire as a CSV, with a leading `Sheet` column |
| `csv/jeremy_legal_catalog_identifiers.csv` | 28 | ISRC / ISWC / work ID / UPC crosswalk for the fake catalogue, with the deliberate holes labelled |

## Formats mirrored

**DistroKid** (`,` delimited, every field in double quotes except the empty trailing `Recoup (USD)`, LF line endings):
`Date Inserted, Reporting Date, Sale Month, Store, Artist, Title, ISRC, UPC, Quantity, Team Percentage, Source Type, Country of Sale, Songwriter Royalties Withheld (USD), Earnings (USD), Recoup (USD)`
Dates are `YYYY-MM-DD`, Sale Month is `YYYY-MM`, earnings have 12 decimal places, withheld is `0.00000`, countries are ISO-2 codes plus `OU` (other/unknown).
ISRCs are written without hyphens. Store names are only names that really appear in DistroKid exports, for example
`Spotify`, `Apple Music`, `YouTube (ContentID)`, `YouTube (Red) - Composition`, `Youtube Shorts`, `Facebook`, `TikTok`, `Snap`, `Amazon Unlimited (Streaming)`, `Deezer`, `Boomplay`, `Saavn`, `Anghami`, `Tencent Direct Deal`, `NetEase`, `Resso`, `LyricFind`, `iTunes Songs`.
The file is meant to be large and messy, like a real export: tiny fractional amounts, some zero-quantity adjustment rows, the same sale month reported across several reporting dates, and a 1 to 12 month reporting lag.

**SoundCloud** (`,` delimited, no quotes): `Reporting Period, Accounting Period, Artist(s), Release, Track, UPC, ISRC, Partner, Country, Type, Units, Revenue (USD), Revenue Share (%), Split Pay Share (%)`. Periods are `YYYY-MM-01`, units and revenue have 9 decimal places. Only `Partner = SOUNDCLOUD` rows are SoundCloud's own money; the other partners in that report are stores DistroKid already reports.

**APRA AMCOS statements** (XLSX, one sheet named `<member>-<AUS|NZ>-<Mon YYYY>`). Rows 1-8 hold metadata
(`APRA AMCOS Royalty Statement`, `APRA|AMCOS Distribution` + Australia/New Zealand, `Period`, `Name`, `Member Number`, `IPI`, `Created` dd/mm/yyyy, `Net Royalty Total` as `AU$ 0.00` / `NZ$ 0.00`). Row 10 is the header:
- APRA: `APRA Distribution, Work ID, Title, Writers, Your Share %, Currency, Tax Withheld, Net Royalty, Category, Territory, Remitting Foreign Society, Additional Details`
- AMCOS: `AMCOS Distribution, Work ID, Title, Writers, Your Share %, Currency, Gross Royalty, Commission, Net Royalty, Category, Client, Territory, Remitting Foreign Society, Additional Details`

Distributions run quarterly in **Feb / May / Aug / Nov**. Distribution codes follow the real pattern:
APRA `P<YY><MM>A|N` with MM one month before the payout (Feb→01, May→04, Aug→07, Nov→10), and
AMCOS `M<YY><MM>A|N` two months before (Feb→previous Dec, May→03, Aug→06, Nov→09). `A` = Australia, `N` = New Zealand.
Amounts are in Excel accounting format. **AUD and NZD are separate currency buckets.** Never add them together, and never add either one to DistroKid USD.
File naming: `APRA Royalty Statement_<member>_<AUS|NZ>_<MonYYYY>.xlsx`.

**Royalty Source Categories List** CSVs: `Distribution, Period Start, Period End, Category, Sub-category, CRD category, Currency, Amount` (AU), and NZ files add `Distribution label` after `Distribution`.

**Works List** (XLSX, sheet `DATA`): `WINFKEY, TITLE, WRITERS, DATE REG, LEGAL SHARE %, AWAITING REG CONFIRMATION, ISRCs`.
The share column is named after the member's surname (`<SURNAME> SHARE %`); here it is `LEGAL SHARE %`. Sole writers are written `SURNAME FIRSTNAME` (`LEGAL JEREMY`) and co-writers as initials (`LEGAL J/SOLICITOR E`). ISRCs are comma-space separated, without hyphens. DATE REG is an Excel datetime.

**PPCA repertoire** (XLSX): `PPL Recording Id, Band/ Artist Name, Recording Title, ISRC, (P)Date, (P)Name, Recording Duration, Country of Recording, Country of Commissioning, Content Type, Valid, My Repertoire, Reported Use`. Duration is `00:00` (hh:mm) and (P)Date is the year.

## The fake catalogue

Artist **Jeremy Legal**. Label **Jeremy Legal Records**. Publisher **JEREMY LEGAL PUBLISHING** (shown in AMCOS `Additional Details`). Writers: LEGAL JEREMY, SOLICITOR ESQ, HOURS BILLABLE, PARALEGAL DJ.

Songs: My Cigar Weeps · Lady With A Bulldog Terrier · Most Toxic Fiat Minimalist (plus Instrumental, Acapella, and a same-master reissue code) · Show Up In The Hatchback · Dread Pirate Jeremy · If It Wasn't For The Invoice · Going Paperless · Diamond Cufflinks & Laser Briefs (plus Instrumental) · Radioactive Billable Hope · All Time Low, Lessons Of Retainer · Terms And Conditions Apply (plus Radio Edit) · Settled Out Of Court · Fiduciary Slang (plus Radio Edit) · We Are Not So Billable (two same-master codes) · Notary Superstar · Don't Shake The Filing Cabinet · and a guest feature, *Habeas Corpus Groove* by DJ Paralegal.

Identifiers are obvious placeholders:
- ISRC `BH-CCB-26-00001` upwards (written `BHCCB2600001` in the files, matching the real exports)
- ISWC `T-000.000.001-0` upwards, APRA work IDs `GW90000001` upwards, IPI `00000000001`, member number `000000`, PPL ids `000000001` upwards, UPCs `000000260001` upwards

**Demo "golden nuggets"**
- *My Cigar Weeps* does unusually well in **Germany**.
- *Lady With A Bulldog Terrier* **goes viral in Nov 2025**. TikTok, Shorts, Facebook and Snap spike first, streams follow, and it reaches the Feb/May 2026 APRA statements.
- Two or three standout songs and a long tail of small earners.

**Deliberate registration holes (Register tab)**
- *Notary Superstar* (`BHCCB2600021`) earns money but has **no APRA work**.
- *Going Paperless* has an APRA work (`GW90000008`) but **no ISRC linked** on the Works List.
- *Radioactive Billable Hope* lists a sole writer at **75%**, so the split doesn't add to 100%.
- *Fiduciary Slang*'s work also lists an older code (`BHCCB1900027`) that never earned; a later code on the same work is paid (Register: old codes).
- Two placeholder works hold reserved ISRCs with no released master (`X001 …`, `X003 …`). A third placeholder (`X002 …`) has no ISRC and picks up one unmatched AMCOS line.

## How the numbers were made

The pack comes from a generator with a fixed seed, so it is the same every time.

DistroKid rows are drawn per sale month × song × country × store from a Poisson model. The model has these inputs:
- **Store and country mix:** a blend of reference shapes and the public platform-popularity patterns listed below. Each weight is then randomly jittered.
- **Per-stream rates by store:** reference ranges and public-ish priors, then jittered.
- **Reporting lag:** a jittered lag distribution.

Statement amounts and the SoundCloud report are generated separately, each on its own sub-seed.

### Public sources for the store-by-country patterns
- DistroKid Help Center, *Which Services and Stores Does DistroKid Send Music To?* (store list incl. Saavn, Anghami, Boomplay, Snapchat, NetEase, Tencent, Audiomack, Pandora, iHeartRadio). https://support.distrokid.com/hc/en-us/articles/360013649093
- DistroKid Help Center, *What Countries Will My Music Be Available In?* (Saavn limited to India/Pakistan/Nepal/Sri Lanka/Bhutan for non-Indian catalogue, Anghami international catalogue Middle East only). https://support.distrokid.com/hc/en-us/articles/360013648113
- Music Business Worldwide on MIDiA Research 2025 subscriber shares (Spotify 31.4%, Tencent 13.8%, Apple 12.6%, YouTube Music 12.4%, Amazon 8.5%; YouTube Music No.1 in MENA; Spotify leads Americas and Europe). https://www.musicbusinessworldwide.com/the-music-industry-is-closing-in-on-a-billion-global-subscribers-with-spotify-out-in-front/
- Mordor Intelligence, *Music Streaming Market* (Tencent/NetEase in China, Boomplay in Africa, Anghami in MENA). https://www.mordorintelligence.com/industry-reports/music-streaming-market
- Growth Market Reports, *Music Streaming Market* (JioSaavn in South Asia, Boomplay in Sub-Saharan Africa, Anghami in the Arab-speaking Middle East). https://growthmarketreports.com/report/music-streaming-market-global-industry-analysis
- Reuters / India PIB, India blocks TikTok (June 2020), so the demo has no TikTok rows in India. https://www.reuters.com/article/technology/india-bans-59-mostly-chinese-apps-amid-border-crisis-idUSKBN24025A/
- Spotify Newsroom / Reuters, Spotify suspends service in Russia (2022), so the demo has no Spotify rows in Russia. https://newsroom.spotify.com/2022-03-02/spotifys-statement-in-response-to-the-war-in-ukraine/

Some country weightings are general industry knowledge rather than a single cited figure and should be read as illustrative only: Deezer strong in France, Snapchat strong in India and Saudi Arabia, YouTube heavy in India/Brazil/SE Asia, Resso in Brazil/Indonesia, Yandex in CIS, Pandora and iHeartRadio US-only.

## Caveats
- ISRC year `26` is used on every code except the one old code (`19`), even for songs that earn from 2024. Real ISRC years reflect when the code was assigned.
- The `BH` country / `CCB` registrant prefix was chosen as a placeholder. It is not checked against the live ISRC registrant list. Treat it as demo-only.
